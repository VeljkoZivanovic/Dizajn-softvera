# gerumap-tim_mladenmatic_veljkozivanovic
gerumap-tim_mladenmatic_veljkozivanovic created by GitHub Classroom
Veljko Zivanovic 122/20 RN
Mladen Matic 110/21 RN
https://www.notion.so/GeRuMap-7afe38efedf947a2a5783d49733f2684
https://www.notion.so/Klasni-dijagram-b08c5e9b0c024802ac104f96ada2b833
