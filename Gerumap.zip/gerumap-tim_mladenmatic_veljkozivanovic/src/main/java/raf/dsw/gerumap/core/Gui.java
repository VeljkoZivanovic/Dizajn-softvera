package raf.dsw.gerumap.core;

import raf.dsw.gerumap.Observer.Subscriber;

public interface Gui extends Subscriber {

    void start();
}
