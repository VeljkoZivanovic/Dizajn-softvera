package raf.dsw.gerumap.gui.swing.view.rightView;

import java.awt.*;

public  abstract class ElementPainter {

    public abstract void paint(Graphics2D g);

    public abstract boolean elementAt(int x, int y);

}
