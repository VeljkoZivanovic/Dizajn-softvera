package raf.dsw.gerumap.gui.swing.controller;

import raf.dsw.gerumap.core.ApplicationFramework;
import raf.dsw.gerumap.gui.swing.view.MainFrame;
import raf.dsw.gerumap.mapRepository.implementation.MindMap;
import raf.dsw.gerumap.mapRepository.implementation.Project;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.io.File;

public class SaveTemplate extends AbstractGerumapAction{
    public SaveTemplate(){
        putValue(ACCELERATOR_KEY, KeyStroke.getKeyStroke(
                KeyEvent.VK_S, ActionEvent.CTRL_MASK));
        //putValue(SMALL_ICON, loadIcon("images/filesave.png"));
        putValue(NAME, "Save mindmap");
        putValue(SHORT_DESCRIPTION, "Save mindmap");
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        JFileChooser jfc = new JFileChooser();

        if (!(MainFrame.getInstance().getMapTree().getSelectedNode().getMapNode() instanceof MindMap)) return;


        MindMap mindmap = (MindMap) MainFrame.getInstance().getMapTree().getSelectedNode().getMapNode();
        File mindmapFile = null;


        if (mindmap.getFileName() == null) {
            if (jfc.showSaveDialog(MainFrame.getInstance()) == JFileChooser.APPROVE_OPTION) {
                mindmapFile = jfc.getSelectedFile();
                System.out.println("PERAZIKAMIKA");
                mindmap.setFileName(mindmapFile.getPath());
            } else {
                return;
            }

        }

        ApplicationFramework.getInstance().getSerializer().saveMindMap(mindmap);
        System.out.println("PERAZIKAMIKA");
        mindmap.setChanged(false);
    }
}
