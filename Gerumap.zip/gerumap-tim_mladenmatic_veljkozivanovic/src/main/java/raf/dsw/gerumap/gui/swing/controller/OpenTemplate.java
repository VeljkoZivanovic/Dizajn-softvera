package raf.dsw.gerumap.gui.swing.controller;

import raf.dsw.gerumap.core.ApplicationFramework;
import raf.dsw.gerumap.gui.swing.view.MainFrame;
import raf.dsw.gerumap.mapRepository.implementation.MindMap;
import raf.dsw.gerumap.mapRepository.implementation.Project;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.io.File;

public class OpenTemplate extends AbstractGerumapAction{
    public OpenTemplate(){
        putValue(ACCELERATOR_KEY, KeyStroke.getKeyStroke(
                KeyEvent.VK_S, ActionEvent.CTRL_MASK));
        //putValue(SMALL_ICON, loadIcon("images/filesave.png"));
        putValue(NAME, "Open mindmap");
        putValue(SHORT_DESCRIPTION, "Open mindmap");
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        JFileChooser jfc = new JFileChooser();

        if (jfc.showOpenDialog(MainFrame.getInstance()) == JFileChooser.APPROVE_OPTION) {
            try {
                File file = jfc.getSelectedFile();
                MindMap m = ApplicationFramework.getInstance().getSerializer().loadMindMap(file);
                MainFrame.getInstance().getMapTree().loadMindMap(m);
                ApplicationFramework.getInstance().getMapRepository().loadMindMap(m);

            } catch (Exception e1) {
                e1.printStackTrace();
            }
        }
    }
}
