package raf.dsw.gerumap.Observer;

public interface Subscriber
{
    void update (Object notification);
}
